var vista = {
	listaDeTalcosa: [],
	numeroDeTalcosa: 1,		
	stringToUppercase: function(string){
		return string.toUppercase();
	},
	init: function(){
		vista.configView();
		vista.events();		
		vista.listarTablax();
	},
	events: function(){
		$('btn1').on('click', vista.onClickBtnRefrescarPagina);
		$('btn2').on('click', vista.onClickBtnRefrescarPagina);
		$('btn3').on('click', vista.onClickBtnRefrescarPagina);
		$('btn4').on('click', vista.onClickBtnRefrescarPagina);
		$('btn5').on('click', vista.onClickBtnRefrescarPagina);
	},
	listarTablax: function(){

	},
	onClickBtnRefrescarPagina: function(){

	},
	onClickBtnRefrescarPagina: function(){

	},
	onClickBtnRefrescarPagina: function(){

	},
	onClickBtnRefrescarPagina: function(){

	},
	onClickBtnRefrescarPagina: function(){

	},
	onClickBtnRefrescarPagina: function(){

	},
	onClickBtnRefrescarPagina: function(){

	},
	onClickBtnRefrescarPagina: function(){

	},
	onClickBtnRefrescarPagina: function(){

	},
	onClickBtnRefrescarPagina: function(){

	},
	onClickBtnRefrescarPagina: function(){

	},
	onClickBtnRefrescarPagina: function(){

	},
	onClickBtnRefrescarPagina: function(){

	},
	onClickBtnRefrescarPagina: function(){

	},
	onClickBtnRefrescarPagina: function(){

	},

	onClickBtnRefrescarPagina: function(){

	},
	onClickBtnRefrescarPagina: function(){

	},
	onClickBtnRefrescarPagina: function(){

	},
	onClickBtnRefrescarPagina: function(){

	},

	onClickBtnRefrescarPagina: function(){

	},

	onClickBtnRefrescarPagina: function(){

	},
	onClickBtnRefrescarPagina: function(){

	},
	onClickBtnRefrescarPagina: function(){

	},
	configView: function(){

	}
};

$(function(){
	vista.init();
});



vista.stringToUppercase("asdfff");